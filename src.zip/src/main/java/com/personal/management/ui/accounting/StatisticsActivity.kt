package com.personal.management.ui.accounting

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.personal.management.databinding.ActivityStatisticsBinding
import java.util.*

/**
 * 统计分析界面
 */
class StatisticsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatisticsBinding
    private lateinit var viewModel: AccountingViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatisticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[AccountingViewModel::class.java]

        setupButtons()
        
        // 默认显示本月统计
        loadMonthStats()
    }

    private fun setupButtons() {
        binding.btnDay.setOnClickListener { loadDayStats() }
        binding.btnMonth.setOnClickListener { loadMonthStats() }
        binding.btnQuarter.setOnClickListener { loadQuarterStats() }
        binding.btnYear.setOnClickListener { loadYearStats() }
        binding.btnBack.setOnClickListener { finish() }
    }

    private fun loadDayStats() {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val start = calendar.timeInMillis
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        val end = calendar.timeInMillis
        
        updateStats("今日支出统计", start, end)
    }

    private fun loadMonthStats() {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val start = calendar.timeInMillis
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        val end = calendar.timeInMillis
        
        updateStats("本月支出统计", start, end)
    }

    private fun loadQuarterStats() {
        val calendar = Calendar.getInstance()
        val month = calendar.get(Calendar.MONTH)
        val quarterStartMonth = (month / 3) * 3
        calendar.set(Calendar.MONTH, quarterStartMonth)
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        val start = calendar.timeInMillis
        
        calendar.set(Calendar.MONTH, quarterStartMonth + 2)
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        val end = calendar.timeInMillis
        
        updateStats("本季度支出统计", start, end)
    }

    private fun loadYearStats() {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.MONTH, Calendar.JANUARY)
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        val start = calendar.timeInMillis
        
        calendar.set(Calendar.MONTH, Calendar.DECEMBER)
        calendar.set(Calendar.DAY_OF_MONTH, 31)
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        val end = calendar.timeInMillis
        
        updateStats("本年度支出统计", start, end)
    }

    private fun updateStats(title: String, start: Long, end: Long) {
        binding.tvStatTitle.text = title
        
        viewModel.getTotalAmount(start, end).observe(this) { total ->
            binding.tvTotalAmount.text = String.format("总计: ¥ %.2f", total ?: 0.0)
        }

        viewModel.getCategoryStats(start, end).observe(this) { stats ->
            val entries = stats.map { PieEntry(it.amount.toFloat(), it.category) }
            val dataSet = PieDataSet(entries, "")
            dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()
            dataSet.valueTextSize = 14f
            
            val pieData = PieData(dataSet)
            binding.pieChart.data = pieData
            binding.pieChart.description.isEnabled = false
            binding.pieChart.centerText = "支出占比"
            binding.pieChart.invalidate()
        }
    }
}
