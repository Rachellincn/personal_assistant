package com.personal.management.ui.accounting

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.personal.management.R
import com.personal.management.data.Bill
import com.personal.management.databinding.ActivityAddBillBinding
import java.text.SimpleDateFormat
import java.util.*

/**
 * 添加或编辑账单的界面
 */
class AddBillActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddBillBinding
    private lateinit var viewModel: AccountingViewModel
    private var selectedDate: Calendar = Calendar.getInstance()
    private var billId: Int = 0 // 0 表示添加，非 0 表示编辑

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBillBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[AccountingViewModel::class.java]

        // 设置分类选择器
        val categories = arrayOf(
            getString(R.string.category_food),
            getString(R.string.category_traffic),
            getString(R.string.category_shopping),
            getString(R.string.category_other)
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        binding.spinnerCategory.adapter = adapter

        // 设置日期选择
        updateDateText()
        binding.btnDatePicker.setOnClickListener {
            showDatePicker()
        }

        // 检查是否为编辑模式
        if (intent.hasExtra("bill_id")) {
            billId = intent.getIntExtra("bill_id", 0)
            binding.etAmount.setText(intent.getDoubleExtra("amount", 0.0).toString())
            binding.etRemark.setText(intent.getStringExtra("remark"))
            val category = intent.getStringExtra("category")
            val index = categories.indexOf(category)
            if (index >= 0) binding.spinnerCategory.setSelection(index)
            selectedDate.timeInMillis = intent.getLongExtra("date", System.currentTimeMillis())
            updateDateText()
            binding.btnSave.text = "更新账单"
        }

        // 保存按钮
        binding.btnSave.setOnClickListener {
            saveBill()
        }

        // 取消按钮
        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun showDatePicker() {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate.set(year, month, dayOfMonth)
                updateDateText()
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateDateText() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        binding.tvSelectedDate.text = sdf.format(selectedDate.time)
    }

    private fun saveBill() {
        val amountStr = binding.etAmount.text.toString()
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "请输入金额", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "请输入有效的金额", Toast.LENGTH_SHORT).show()
            return
        }

        val category = binding.spinnerCategory.selectedItem.toString()
        val remark = binding.etRemark.text.toString()
        val date = selectedDate.timeInMillis

        val bill = Bill(id = billId, amount = amount, category = category, date = date, remark = remark)
        
        if (billId == 0) {
            viewModel.insert(bill)
            Toast.makeText(this, "添加成功", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.update(bill)
            Toast.makeText(this, "更新成功", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
