package com.personal.management.ui.accounting

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.personal.management.data.Bill
import com.personal.management.databinding.ItemBillBinding
import java.text.SimpleDateFormat
import java.util.*

/**
 * 账单列表适配器
 */
class BillAdapter(
    private var bills: List<Bill>,
    private val onItemClick: (Bill) -> Unit,
    private val onItemLongClick: (Bill) -> Unit
) : RecyclerView.Adapter<BillAdapter.BillViewHolder>() {

    class BillViewHolder(val binding: ItemBillBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BillViewHolder {
        val binding = ItemBillBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BillViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BillViewHolder, position: Int) {
        val bill = bills[position]
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        
        holder.binding.tvCategory.text = bill.category
        holder.binding.tvAmount.text = String.format("¥ %.2f", bill.amount)
        holder.binding.tvDate.text = sdf.format(Date(bill.date))
        holder.binding.tvRemark.text = bill.remark

        holder.itemView.setOnClickListener { onItemClick(bill) }
        holder.itemView.setOnLongClickListener {
            onItemLongClick(bill)
            true
        }
    }

    override fun getItemCount() = bills.size

    fun updateBills(newBills: List<Bill>) {
        bills = newBills
        notifyDataSetChanged()
    }
}
