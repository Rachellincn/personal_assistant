package com.personal.management.ui.accounting

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.personal.management.databinding.FragmentAccountingBinding

/**
 * 记账功能模块主界面
 */
class AccountingFragment : Fragment() {

    private var _binding: FragmentAccountingBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: AccountingViewModel
    private lateinit var adapter: BillAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAccountingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[AccountingViewModel::class.java]

        setupRecyclerView()

        binding.fabAddBill.setOnClickListener {
            val intent = Intent(requireContext(), AddBillActivity::class.java)
            startActivity(intent)
        }

        binding.btnStatistics.setOnClickListener {
            // 跳转到统计界面
            val intent = Intent(requireContext(), StatisticsActivity::class.java)
            startActivity(intent)
        }

        viewModel.allBills.observe(viewLifecycleOwner) { bills ->
            adapter.updateBills(bills)
        }
    }

    private fun setupRecyclerView() {
        adapter = BillAdapter(
            emptyList(),
            onItemClick = { bill ->
                // 编辑账单
                val intent = Intent(requireContext(), AddBillActivity::class.java).apply {
                    putExtra("bill_id", bill.id)
                    putExtra("amount", bill.amount)
                    putExtra("category", bill.category)
                    putExtra("date", bill.date)
                    putExtra("remark", bill.remark)
                }
                startActivity(intent)
            },
            onItemLongClick = { bill ->
                // 删除账单
                AlertDialog.Builder(requireContext())
                    .setTitle("确认删除")
                    .setMessage("确定要删除这条账单吗？")
                    .setPositiveButton("确定") { _, _ ->
                        viewModel.delete(bill)
                    }
                    .setNegativeButton("取消", null)
                    .show()
            }
        )
        binding.rvBills.layoutManager = LinearLayoutManager(requireContext())
        binding.rvBills.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
