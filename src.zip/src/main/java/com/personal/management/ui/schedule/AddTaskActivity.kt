package com.personal.management.ui.schedule

import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.personal.management.data.Task
import com.personal.management.databinding.ActivityAddTaskBinding
import java.util.*

/**
 * 添加或编辑日程事项的界面
 */
class AddTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskBinding
    private lateinit var viewModel: ScheduleViewModel
    private var selectedTime: Calendar = Calendar.getInstance()
    private var taskId: Int = 0
    private var isTomorrow: Boolean = true // 默认创建明天的安排

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[ScheduleViewModel::class.java]
        isTomorrow = intent.getBooleanExtra("is_tomorrow", true)

        // 设置优先级选择器
        val priorities = arrayOf("低", "中", "高")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, priorities)
        binding.spinnerPriority.adapter = adapter

        // 设置时间选择
        updateTimeText()
        binding.btnTimePicker.setOnClickListener {
            showTimePicker()
        }

        // 检查是否为编辑模式
        if (intent.hasExtra("task_id")) {
            taskId = intent.getIntExtra("task_id", 0)
            binding.etDescription.setText(intent.getStringExtra("description"))
            binding.spinnerPriority.setSelection(intent.getIntExtra("priority", 0))
            val time = intent.getStringExtra("time") ?: "09:00"
            val parts = time.split(":")
            if (parts.size == 2) {
                selectedTime.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                selectedTime.set(Calendar.MINUTE, parts[1].toInt())
            }
            updateTimeText()
            binding.btnSave.text = "更新事项"
        }

        // 保存按钮
        binding.btnSave.setOnClickListener {
            saveTask()
        }

        // 取消按钮
        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun showTimePicker() {
        TimePickerDialog(
            this,
            { _, hour, minute ->
                selectedTime.set(Calendar.HOUR_OF_DAY, hour)
                selectedTime.set(Calendar.MINUTE, minute)
                updateTimeText()
            },
            selectedTime.get(Calendar.HOUR_OF_DAY),
            selectedTime.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun updateTimeText() {
        val timeStr = String.format("%02d:%02d", selectedTime.get(Calendar.HOUR_OF_DAY), selectedTime.get(Calendar.MINUTE))
        binding.tvSelectedTime.text = timeStr
    }

    private fun saveTask() {
        val description = binding.etDescription.text.toString()
        if (description.isEmpty()) {
            Toast.makeText(this, "请输入事项描述", Toast.LENGTH_SHORT).show()
            return
        }

        val priority = binding.spinnerPriority.selectedItemPosition
        val time = binding.tvSelectedTime.text.toString()
        
        // 计算日期
        val calendar = Calendar.getInstance()
        if (isTomorrow) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        val date = calendar.timeInMillis

        val task = Task(
            id = taskId,
            description = description,
            time = time,
            priority = priority,
            date = date,
            isCompleted = intent.getBooleanExtra("is_completed", false),
            summary = intent.getStringExtra("summary") ?: ""
        )
        
        if (taskId == 0) {
            viewModel.insert(task)
            Toast.makeText(this, "添加成功", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.update(task)
            Toast.makeText(this, "更新成功", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
