package com.personal.management.ui.schedule

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.personal.management.data.Task
import com.personal.management.databinding.ItemTaskBinding

/**
 * 日程事项列表适配器
 */
class TaskAdapter(
    private var tasks: List<Task>,
    private val onItemClick: (Task) -> Unit,
    private val onCompleteClick: (Task, Boolean) -> Unit,
    private val onItemLongClick: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    class TaskViewHolder(val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        
        holder.binding.tvDescription.text = task.description
        holder.binding.tvTime.text = task.time
        
        // 修复：先清除监听器，再设置状态，避免由于复用导致的错乱
        holder.binding.cbComplete.setOnCheckedChangeListener(null)
        holder.binding.cbComplete.isChecked = task.isCompleted
        
        // UI 优化：根据完成状态调整文字样式
        if (task.isCompleted) {
            holder.binding.tvDescription.paintFlags = holder.binding.tvDescription.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            holder.binding.tvDescription.alpha = 0.5f
        } else {
            holder.binding.tvDescription.paintFlags = holder.binding.tvDescription.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            holder.binding.tvDescription.alpha = 1.0f
        }
        
        val priorityStr = when(task.priority) {
            0 -> "低"
            1 -> "中"
            2 -> "高"
            else -> "低"
        }
        holder.binding.tvPriority.text = "优先级: $priorityStr"

        holder.binding.cbComplete.setOnCheckedChangeListener { _, isChecked ->
            // 只有当状态真正改变时才触发回调
            if (isChecked != task.isCompleted) {
                onCompleteClick(task, isChecked)
            }
        }

        holder.itemView.setOnClickListener { onItemClick(task) }
        holder.itemView.setOnLongClickListener {
            onItemLongClick(task)
            true
        }
    }

    override fun getItemCount() = tasks.size

    fun updateTasks(newTasks: List<Task>) {
        tasks = newTasks
        notifyDataSetChanged()
    }
}
