package com.personal.management.ui.schedule

import android.app.Application
import androidx.lifecycle.*
import com.personal.management.data.AppDatabase
import com.personal.management.data.Task
import kotlinx.coroutines.launch
import java.util.*

/**
 * 日程模块的 ViewModel
 */
class ScheduleViewModel(application: Application) : AndroidViewModel(application) {

    private val taskDao = AppDatabase.getDatabase(application).taskDao()

    private val _selectedDate = MutableLiveData<Long>()
    
    // 使用 switchMap 确保只有一个 LiveData 被观察，并自动处理日期切换
    val tasks: LiveData<List<Task>> = _selectedDate.switchMap { timestamp ->
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = timestamp
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val start = calendar.timeInMillis
        
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val end = calendar.timeInMillis
        
        taskDao.getTasksByDate(start, end)
    }

    fun setDate(timestamp: Long) {
        _selectedDate.value = timestamp
    }

    // 插入任务
    fun insert(task: Task) = viewModelScope.launch {
        taskDao.insertTask(task)
    }

    // 更新任务
    fun update(task: Task) = viewModelScope.launch {
        taskDao.updateTask(task)
    }

    // 删除任务
    fun delete(task: Task) = viewModelScope.launch {
        taskDao.deleteTask(task)
    }

    // 标记完成
    fun markComplete(id: Int, isCompleted: Boolean, summary: String = "") = viewModelScope.launch {
        taskDao.markTaskComplete(id, isCompleted, summary)
    }
}
