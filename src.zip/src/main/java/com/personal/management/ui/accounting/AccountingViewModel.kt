package com.personal.management.ui.accounting

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.personal.management.data.AppDatabase
import com.personal.management.data.Bill
import com.personal.management.data.CategorySum
import kotlinx.coroutines.launch
import java.util.*

/**
 * 记账模块的 ViewModel，处理业务逻辑
 */
class AccountingViewModel(application: Application) : AndroidViewModel(application) {

    private val billDao = AppDatabase.getDatabase(application).billDao()
    
    // 获取所有账单
    val allBills: LiveData<List<Bill>> = billDao.getAllBills()

    // 插入账单
    fun insert(bill: Bill) = viewModelScope.launch {
        billDao.insertBill(bill)
    }

    // 更新账单
    fun update(bill: Bill) = viewModelScope.launch {
        billDao.updateBill(bill)
    }

    // 删除账单
    fun delete(bill: Bill) = viewModelScope.launch {
        billDao.deleteBill(bill)
    }

    // 获取特定时间范围的账单
    fun getBillsByRange(start: Long, end: Long): LiveData<List<Bill>> {
        return billDao.getBillsByTimeRange(start, end)
    }

    // 获取特定时间范围的总金额
    fun getTotalAmount(start: Long, end: Long): LiveData<Double?> {
        return billDao.getTotalAmountByTimeRange(start, end)
    }

    // 获取分类统计数据
    fun getCategoryStats(start: Long, end: Long): LiveData<List<CategorySum>> {
        return billDao.getCategoryStatsByTimeRange(start, end)
    }
}
