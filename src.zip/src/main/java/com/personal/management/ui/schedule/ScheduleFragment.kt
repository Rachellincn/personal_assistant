package com.personal.management.ui.schedule

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.personal.management.databinding.FragmentScheduleBinding
import java.util.*

/**
 * 日程管理功能模块主界面
 */
class ScheduleFragment : Fragment() {

    private var _binding: FragmentScheduleBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ScheduleViewModel
    private lateinit var adapter: TaskAdapter
    private var isTomorrowTab: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScheduleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[ScheduleViewModel::class.java]

        setupRecyclerView()
        setupTabs()

        binding.fabAddTask.setOnClickListener {
            val intent = Intent(requireContext(), AddTaskActivity::class.java).apply {
                putExtra("is_tomorrow", isTomorrowTab)
            }
            startActivity(intent)
        }

        // 观察 ViewModel 中的任务列表
        viewModel.tasks.observe(viewLifecycleOwner) { tasks ->
            adapter.updateTasks(tasks)
        }
        
        // 初始加载当前日期的任务
        updateDate()
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                isTomorrowTab = tab?.position == 1
                updateDate()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun updateDate() {
        val calendar = Calendar.getInstance()
        if (isTomorrowTab) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        viewModel.setDate(calendar.timeInMillis)
    }

    private fun setupRecyclerView() {
        adapter = TaskAdapter(
            emptyList(),
            onItemClick = { task ->
                val intent = Intent(requireContext(), AddTaskActivity::class.java).apply {
                    putExtra("task_id", task.id)
                    putExtra("description", task.description)
                    putExtra("time", task.time)
                    putExtra("priority", task.priority)
                    putExtra("is_tomorrow", isTomorrowTab)
                    putExtra("is_completed", task.isCompleted)
                    putExtra("summary", task.summary)
                }
                startActivity(intent)
            },
            onCompleteClick = { task, isChecked ->
                // 修复：状态标记逻辑修复
                if (isChecked && !isTomorrowTab && task.summary.isEmpty()) {
                    showSummaryDialog(task)
                } else {
                    viewModel.markComplete(task.id, isChecked, task.summary)
                }
            },
            onItemLongClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle("确认删除")
                    .setMessage("确定要删除这条事项吗？")
                    .setPositiveButton("确定") { _, _ ->
                        viewModel.delete(task)
                    }
                    .setNegativeButton("取消", null)
                    .show()
            }
        )
        binding.rvTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTasks.adapter = adapter
    }

    private fun showSummaryDialog(task: com.personal.management.data.Task) {
        val editText = android.widget.EditText(requireContext())
        editText.hint = "输入今日总结..."
        AlertDialog.Builder(requireContext())
            .setTitle("今日总结")
            .setView(editText)
            .setPositiveButton("完成") { _, _ ->
                viewModel.markComplete(task.id, true, editText.text.toString())
            }
            .setNegativeButton("仅标记完成") { _, _ ->
                viewModel.markComplete(task.id, true, "")
            }
            .setCancelable(false)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
