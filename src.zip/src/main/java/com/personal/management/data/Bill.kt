package com.personal.management.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

/**
 * 账单数据模型
 */
@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amount: Double,           // 金额
    val category: String,         // 分类 (如：餐饮、交通、购物等)
    val date: Long,               // 日期 (时间戳)
    val remark: String = ""       // 备注
)
