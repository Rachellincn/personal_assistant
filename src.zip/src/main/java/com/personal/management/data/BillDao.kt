package com.personal.management.data

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * 账单数据访问对象
 */
@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY date DESC")
    fun getAllBills(): LiveData<List<Bill>>

    @Query("SELECT * FROM bills WHERE date >= :startTime AND date <= :endTime ORDER BY date DESC")
    fun getBillsByTimeRange(startTime: Long, endTime: Long): LiveData<List<Bill>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: Bill)

    @Update
    suspend fun updateBill(bill: Bill)

    @Delete
    suspend fun deleteBill(bill: Bill)

    @Query("SELECT SUM(amount) FROM bills WHERE date >= :startTime AND date <= :endTime")
    fun getTotalAmountByTimeRange(startTime: Long, endTime: Long): LiveData<Double?>

    @Query("SELECT category, SUM(amount) as amount FROM bills WHERE date >= :startTime AND date <= :endTime GROUP BY category")
    fun getCategoryStatsByTimeRange(startTime: Long, endTime: Long): LiveData<List<CategorySum>>
}

/**
 * 分类统计辅助类
 */
data class CategorySum(
    val category: String,
    val amount: Double
)
