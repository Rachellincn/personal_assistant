package com.personal.management.data

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * 日程数据访问对象
 */
@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE date >= :startTime AND date <= :endTime ORDER BY time ASC")
    fun getTasksByDate(startTime: Long, endTime: Long): LiveData<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)

    @Query("UPDATE tasks SET isCompleted = :isCompleted, summary = :summary WHERE id = :id")
    suspend fun markTaskComplete(id: Int, isCompleted: Boolean, summary: String)
}
