package com.personal.management.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 日程事项数据模型
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val description: String,      // 事项描述
    val time: String,             // 时间 (如：09:00)
    val priority: Int,            // 优先级 (0: 低, 1: 中, 2: 高)
    val isCompleted: Boolean = false, // 是否完成
    val date: Long,               // 日期 (时间戳，用于区分今日和明日)
    val summary: String = ""      // 今日总结 (仅对已完成事项有效)
)
